# CNN_with_numpy

- Each functions are created in different \*.py files
- The implementation on the Mnist dataset is at implemet2.ipynb
